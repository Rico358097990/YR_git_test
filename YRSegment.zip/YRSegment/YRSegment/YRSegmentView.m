

//
//  YRSegmentView.m
//  YRSegment
//
//  Created by shenguang on 16/5/10.
//  Copyright © 2016年 ShanDongShenGuang. All rights reserved.
//

#import "YRSegmentView.h"
#import "YRSegmentContentView.h"
#import "YRSegmentViewUnit.h"

@interface YRSegmentView ()<YRSegmentContentViewDelegate,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>

@property (nonatomic, strong)YRSegmentContentView * titleView;
@property (nonatomic, strong)UICollectionViewFlowLayout * cLayout;
@property (nonatomic, strong)UICollectionView * collectionView;
@end

@implementation YRSegmentView

- (instancetype)initWithFrame:(CGRect)frame andHeight:(CGFloat)height andViewControllers:(NSArray<UIViewController *> *)viewControllers{
    self = [super initWithFrame:frame];
    if (self) {
        _height = height;
        _viewControllers = viewControllers;
        [self setupAllViews];
    }
    return self;
}


- (void)setupAllViews{
    NSMutableArray * titleArr = [[NSMutableArray alloc] init];
    for (UIViewController *vc in _viewControllers) {
        [titleArr addObject:vc.title];
    }
    
    self.titleView = [[YRSegmentContentView alloc]initWithFrame:CGRectZero andTitles:titleArr];
    self.titleView.delegate = self;
    [self addSubview:self.titleView];
    
    self.cLayout = [[UICollectionViewFlowLayout alloc]init];
    
    _cLayout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    self.collectionView = [[UICollectionView alloc] initWithFrame:(CGRectZero) collectionViewLayout:_cLayout];
    self.collectionView.pagingEnabled = YES;
    self.collectionView.delegate = self;
    self.collectionView.dataSource = self;
    
    [self.collectionView registerClass:[YRSegmentViewUnit class] forCellWithReuseIdentifier:@"item"];
    [self.collectionView addObserver:self forKeyPath:@"contentOffset" options:NSKeyValueObservingOptionNew context:nil];
    [self addSubview:self.collectionView];
    
    
}

- (void)layoutSubviews{
    self.titleView.frame = CGRectMake(0, 0, self.frame.size.width, _height);
    self.collectionView.frame = CGRectMake(0, _height, self.frame.size.width, self.frame.size.height-_height);
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context{
    CGPoint offset = self.collectionView.contentOffset;
    CGFloat pageFloat = offset.x / self.collectionView.bounds.size.width +0.5;
    NSLog(@"%f",pageFloat);
    if (pageFloat < 0) {
        pageFloat = 0;
    }
    if (pageFloat > _viewControllers.count) {
        pageFloat = _viewControllers.count;
    }
    NSInteger page = (NSInteger)pageFloat;
    self.titleView.page = page;
    
}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return _viewControllers.count;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return 1;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    YRSegmentViewUnit * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"item" forIndexPath:indexPath];
    UIViewController * vc = _viewControllers[indexPath.section];
    if (!vc.isViewLoaded) {
        [vc loadViewIfNeeded];
    }
    
    cell.view = vc.view;
    
    return cell;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    return collectionView.bounds.size;
}


- (void)didSelectedButtonAtIndex:(NSInteger)index{
    CGFloat width = self.collectionView.bounds.size.width;
    [self.collectionView setContentOffset:(CGPointMake(width*index, 0))animated:YES];
    
}


- (void)dealloc{
    [self.collectionView removeObserver:self forKeyPath:@"contentOffset"];
}







@end
