
//
//  YRSegmentViewUnit.m
//  YRSegment
//
//  Created by shenguang on 16/5/11.
//  Copyright © 2016年 ShanDongShenGuang. All rights reserved.
//

#import "YRSegmentViewUnit.h"

@implementation YRSegmentViewUnit

- (void)setView:(UIView *)view{
    if (_view) {
        [_view removeFromSuperview];
    }
    
    [self.contentView addSubview:view];
    [self setNeedsLayout];
    _view = view;
}

- (void)layoutSubviews{
    self.view.frame = self.contentView.frame;
}



@end
