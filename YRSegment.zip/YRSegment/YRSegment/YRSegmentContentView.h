//
//  YRSegmentContentView.h
//  YRSegment
//
//  Created by shenguang on 16/5/10.
//  Copyright © 2016年 ShanDongShenGuang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YRSegmentTitleItem.h"
#import "YRSegmentContentViewDelegate.h"

@interface YRSegmentContentView : UIView

@property (nonatomic, assign)id<YRSegmentContentViewDelegate>delegate;
@property (nonatomic, assign)NSInteger page;

///非选中颜色
@property (nonatomic,strong) UIColor *normalColor;
///选中颜色
@property (nonatomic,strong) UIColor *highlightColor;
///字体
@property (nonatomic,strong) UIFont  *font;

- (instancetype)initWithFrame:(CGRect)frame andTitles:(NSArray<NSString * > *)titles;


@end
