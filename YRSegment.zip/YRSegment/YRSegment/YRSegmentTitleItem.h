//
//  YRSegmentTitleItem.h
//  YRSegment
//
//  Created by shenguang on 16/5/9.
//  Copyright © 2016年 ShanDongShenGuang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YRSegmentTitleItem : UIView

@property (nonatomic, copy) NSString * title;
@property (nonatomic, assign) CGFloat space;
@property (nonatomic, strong)UILabel * titleLabel;
@property (nonatomic,strong) UIFont  *font;
@property (nonatomic, assign)BOOL highlight;
///非选中颜色
@property (nonatomic,strong) UIColor *normalColor;
///选中颜色
@property (nonatomic,strong) UIColor *highlightColor;

- (void)addTarget:(id)target andAction:(SEL)action;
+ (CGFloat)calcuWidth:(NSString*)title;
- (instancetype) initWithFrame:(CGRect)frame andTitle:(NSString *) theTitle;
@end
