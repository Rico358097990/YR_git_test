//
//  YRSegmentViewUnit.h
//  YRSegment
//
//  Created by shenguang on 16/5/11.
//  Copyright © 2016年 ShanDongShenGuang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YRSegmentViewUnit : UICollectionViewCell

@property (nonatomic, strong)UIView * view;

@end
