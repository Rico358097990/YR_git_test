//
//  ViewController.m
//  YRSegment
//
//  Created by shenguang on 16/5/9.
//  Copyright © 2016年 ShanDongShenGuang. All rights reserved.
//

#import "ViewController.h"
#import "YRSegmentView.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIViewController * vc1 = [[UIViewController alloc] init];
    vc1.view.backgroundColor = [UIColor redColor];
    vc1.title = @"xx";
    
    UIViewController * vc2 = [[UIViewController alloc] init];
    vc2.view.backgroundColor = [UIColor blueColor];
    vc2.title = @"gg";
    
    UIViewController * vc3 = [[UIViewController alloc] init];
    vc3.view.backgroundColor = [UIColor grayColor];
    vc3.title = @"hhggg";
    
    
    YRSegmentView * view = [[YRSegmentView alloc] initWithFrame:CGRectMake(0, 20, self.view.bounds.size.width, self.view.bounds.size.height) andHeight:44 andViewControllers:@[vc1,vc2,vc3]];
    view.highlightColor = [UIColor orangeColor];
    [self.view addSubview:view];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
