//
//  YRSegmentView.h
//  YRSegment
//
//  Created by shenguang on 16/5/10.
//  Copyright © 2016年 ShanDongShenGuang. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface YRSegmentView : UIView

///非选中颜色
@property (nonatomic,strong) UIColor *normalColor;
///选中颜色
@property (nonatomic,strong) UIColor *highlightColor;
///字体
@property (nonatomic,strong) UIFont  *font;

@property (nonatomic, assign) CGFloat height;

@property (nonatomic, strong)NSArray<UIViewController *> * viewControllers;



- (instancetype)initWithFrame:(CGRect)frame andHeight:(CGFloat)height andViewControllers:(NSArray<UIViewController *> *)viewControllers;
@end
