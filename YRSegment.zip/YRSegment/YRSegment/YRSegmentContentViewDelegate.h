//
//  YRSegmentContentViewDelegate.h
//  YRSegment
//
//  Created by shenguang on 16/5/10.
//  Copyright © 2016年 ShanDongShenGuang. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol YRSegmentContentViewDelegate <NSObject>

- (void)didSelectedButtonAtIndex:(NSInteger)index;


@end
