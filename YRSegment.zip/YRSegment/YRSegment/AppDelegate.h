//
//  AppDelegate.h
//  YRSegment
//
//  Created by shenguang on 16/5/9.
//  Copyright © 2016年 ShanDongShenGuang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

