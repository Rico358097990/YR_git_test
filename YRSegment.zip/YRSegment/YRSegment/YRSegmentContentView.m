
//
//  YRSegmentContentView.m
//  YRSegment
//
//  Created by shenguang on 16/5/10.
//  Copyright © 2016年 ShanDongShenGuang. All rights reserved.
//

#import "YRSegmentContentView.h"


@interface YRSegmentContentView ()

@property (nonatomic, assign)CGFloat buttonWidthSUM;
@property (nonatomic, strong)YRSegmentTitleItem * crrentItem;
@property (nonatomic, strong)UIView * buttonCurrentView;
@property (nonatomic, strong)UIView * line;
@property (nonatomic, strong)NSMutableArray * buttonArr;
@property (nonatomic, strong)NSMutableArray * buttonWidths;
@property (nonatomic, strong)NSArray * items;

@end

@implementation YRSegmentContentView

- (instancetype)initWithFrame:(CGRect)frame andTitles:(NSArray<NSString * > *)titles{
    self = [super initWithFrame:frame];
    if ( self) {
        self.items = [titles copy];
        [self setupAllButtons];
    }
    return self;
}


- (void)setupAllButtons{
    self.backgroundColor = [UIColor groupTableViewBackgroundColor];
    self.buttonCurrentView  = [[UIView alloc] initWithFrame:CGRectZero];
    self.buttonCurrentView.backgroundColor = [UIColor whiteColor];
    [self addSubview:self.buttonCurrentView];
    
    self.line = [[UIView alloc] initWithFrame:CGRectZero];
    self.line.backgroundColor = [UIColor orangeColor];
    [self addSubview:self.line];
    
    for (NSString * title in _items) {
        YRSegmentTitleItem * item = [[YRSegmentTitleItem alloc] initWithFrame:CGRectZero andTitle:title];
        [item addTarget:self andAction:@selector(click:)];
        [self.buttonArr addObject:item];
        [self.buttonCurrentView addSubview:item];
        
        CGFloat width = [YRSegmentTitleItem calcuWidth:title];
        [self.buttonWidths addObject:[NSNumber numberWithDouble:width]];
        _buttonWidthSUM += width;
        if (_crrentItem == nil) {
            _crrentItem = item;
            item.highlight = YES;
        }
        
    }

}

- (void)click:(YRSegmentTitleItem *)sender{
    NSInteger index = [self.buttonArr indexOfObject:sender];
    [self setPage:index];
    if (self.delegate && [self.delegate respondsToSelector:@selector(didSelectedButtonAtIndex:)]) {
        [self.delegate didSelectedButtonAtIndex:index];
    }
    
}

- (void)setPage:(NSInteger)page{
    if (_page == page) {
        return;
    }
    _page = page;
    [self movetoPage:page];
}

- (void)movetoPage:(NSInteger)page{
    if (page>self.buttonArr.count) {
        return;
    }
    YRSegmentTitleItem * item = self.buttonArr[page];
    _crrentItem.highlight = NO;
    _crrentItem = item;
    item.highlight = YES;
    [UIView animateWithDuration:.2 animations:^{
        CGRect buttonFrame = item.frame;
        CGRect lineFrame = self.line.frame;
        lineFrame.origin.x = buttonFrame.origin.x;
        lineFrame.size.width = buttonFrame.size.width;
        self.line.frame = lineFrame;
    }completion:^(BOOL finished) {
        if (finished) {
            
        }
    }];
}

- (NSMutableArray *)buttonArr{
    if (!_buttonArr) {
        _buttonArr = [[NSMutableArray alloc]init];
    }
    return _buttonArr;
}

- (NSMutableArray *)buttonWidths{
    if (!_buttonWidths) {
        _buttonWidths = [[NSMutableArray alloc]init];
    }
    return _buttonWidths;
}


- (void)layoutSubviews{
    CGFloat height = self.bounds.size.height;
    CGFloat width = self.bounds.size.width;
    
    self.buttonCurrentView.frame = CGRectMake(0, 0, width, height-2);
    
    CGFloat spacing = 0;
    if (_buttonWidthSUM>width) {
        spacing = 0;
    }else{
        spacing = (width - _buttonWidthSUM)/(_buttonWidths.count + 1);
    }
    
    for (int i = 0; i<self.buttonArr.count; i++) {
        YRSegmentTitleItem * item = self.buttonArr[i];
        CGFloat buttonWidth = [self.buttonWidths[i] doubleValue];
        if (i == 0) {
            item.frame = CGRectMake(spacing, 0, buttonWidth, _buttonCurrentView.bounds.size.height);
        }else{
            YRSegmentTitleItem * lastItem = self.buttonArr[i - 1];
            item.frame = CGRectMake(spacing + lastItem.frame.size.width+lastItem.frame.origin.x, 0, buttonWidth, _buttonCurrentView.frame.size.height);
        }
    }
    self.line.frame = CGRectMake(_crrentItem.frame.origin.x, self.buttonCurrentView.bounds.size.height, _crrentItem.bounds.size.width, 2);
}



- (void)setNormalColor:(UIColor *)normalColor {
    if (_normalColor == normalColor) {
        return;
    }
    _normalColor = normalColor;
    for (YRSegmentTitleItem *item in self.buttonArr) {
        item.normalColor = normalColor;
    }
}
- (void)setHighlightColor:(UIColor *)highlightColor {
    if (_highlightColor == highlightColor) {
        return;
    }
    _highlightColor = highlightColor;
    self.line.backgroundColor = highlightColor;
    for (YRSegmentTitleItem *item in self.buttonArr) {
        item.highlightColor = highlightColor;
    }
}

- (void)setFont:(UIFont *)font {
    if (_font == font) {
        return;
    }
    for (YRSegmentTitleItem *item in self.buttonArr) {
        item.font = font;
    }
}









@end
